# lammps_helper
Python code to help with input/output from the molecular dynamics package LAMMPS.
